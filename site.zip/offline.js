const CACHE = 'home-recipe-web-v22-r2';
const POLICY = 'home-recipe-update-policy';

function waitForInstall(worker) {
  return new Promise((resolve, reject) => {
    function check() {
      if (!['installed', 'activated', 'redundant'].includes(worker.state)) return;
      worker.removeEventListener('statechange', check);
      if (worker.state === 'redundant') reject(new Error('更新包安装未完成，请联网重试。'));
      else resolve();
    }
    worker.addEventListener('statechange', check);
    check();
  });
}

async function getRelease() {
  let response;
  try {
    response = await fetch('./release.json', {cache: 'no-store'});
  } catch {
    throw new Error('无法读取版本信息，请联网重试。');
  }
  if (!response.ok) throw new Error('无法读取版本信息，请联网重试。');
  const release = await response.json().catch(() => null);
  if (!release || !/^v[0-9]+$/.test(release.version) ||
      !new RegExp('^home-recipe-web-' + release.version + '(?:-r[0-9]+)?$').test(release.cache)) {
    throw new Error('版本信息无效，请稍后重试。');
  }
  return release;
}

export async function prepareOffline(status, updateButton, updateStatus, updateNotice) {
  if (!('serviceWorker' in navigator)) {
    status.textContent = '此浏览器不支持离线缓存。';
    updateButton.hidden = true;
    return;
  }

  const cache = await caches.open(CACHE);
  const ready = async () => {
    if (await cache.match('./offline-ready')) {
      status.textContent = '离线资源及 PDF 阅读器已就绪 · 网络版 v22';
      return true;
    }
    return false;
  };
  if (!await ready()) status.textContent = '首次准备离线资源，请保持联网…';

  try {
    const registration = await navigator.serviceWorker.register('./sw.js', {updateViaCache: 'none'});
    let checking = false;
    function showWaiting() {
      if (!registration.waiting) return;
      updateNotice.hidden = false;
      updateButton.hidden = true;
      updateStatus.textContent = '';
    }
    function watch(worker) {
      if (!worker) return;
      waitForInstall(worker).then(async () => {
        await ready();
        showWaiting();
      }).catch(async () => {
        if (!await ready()) status.textContent = '离线资源准备失败，请联网刷新重试。';
      });
    }
    registration.addEventListener('updatefound', () => watch(registration.installing));
    watch(registration.installing);
    showWaiting();

    updateButton.onclick = async () => {
      if (checking) return;
      if (registration.waiting) { showWaiting(); return; }
      checking = true;
      updateButton.disabled = true;
      updateStatus.textContent = '正在检查升级…';
      let approval;
      let policy;
      try {
        const release = await getRelease();
        if (release.cache === CACHE) {
          updateStatus.textContent = '当前已是最新版本。';
          return;
        }
        policy = await caches.open(POLICY);
        approval = './.approve-update/' + release.cache;
        await policy.put(approval, new Response(String(Date.now() + 15 * 60 * 1000)));
        updateStatus.textContent = '正在安装 ' + release.version + '…';
        await registration.update();
        if (registration.installing) await waitForInstall(registration.installing);
        if (!registration.waiting) throw new Error('新版本暂未就绪，请稍后再试。');
        showWaiting();
      } catch (error) {
        updateStatus.textContent = error.message || '无法升级，请联网重试。';
      } finally {
        if (approval) await policy.delete(approval).catch(() => {});
        checking = false;
        updateButton.disabled = false;
      }
    };

    if (!registration.waiting && navigator.onLine) {
      getRelease().then(release => {
        if (!checking && !registration.waiting && release.cache !== CACHE) {
          updateButton.textContent = '升级';
          updateStatus.textContent = '发现新版 ' + release.version + '。';
        }
      }).catch(() => {});
    }
  } catch (error) {
    if (!await ready()) status.textContent = '离线准备未完成，请联网刷新重试。';
    updateStatus.textContent = error.message || '无法检查升级。';
  }
}

