const CACHE='home-recipe-web-v15';
export async function prepareOffline(status,updateButton){
 if(!('serviceWorker' in navigator)){status.textContent='此浏览器不支持离线缓存。';return;}
 const hadController=!!navigator.serviceWorker.controller;
 if(hadController)navigator.serviceWorker.addEventListener('controllerchange',()=>location.reload(),{once:true});
 const cache=await caches.open(CACHE);let cached=!!await cache.match('./offline-ready');
 const ready=()=>{status.textContent='离线资源及 PDF 阅读器已就绪 · 网络版 v15';};
 if(cached)ready();else status.textContent='首次准备离线资源，请保持联网…';
 try{
  const reg=await navigator.serviceWorker.register('./sw.js',{updateViaCache:'none'});
  const offer=()=>{if(!reg.waiting)return;updateButton.textContent='新版本就绪 · 查看更新方法';updateButton.hidden=false;updateButton.onclick=()=>{status.textContent='请先保存修改，关闭所有菜谱标签页和应用窗口，再重新打开。新版本会在旧窗口全部关闭后启用。';};};
  const watch=worker=>{if(!worker)return;const check=async()=>{if(worker.state==='installed'||worker.state==='activated'){offer();const complete=await cache.match('./offline-ready');if(complete){cached=true;ready();}}else if(worker.state==='redundant'&&!cached)status.textContent='离线资源下载未完成，请联网刷新重试。';};worker.addEventListener('statechange',check);check();};
  reg.addEventListener('updatefound',()=>watch(reg.installing));watch(reg.installing);offer();
  await reg.update();
  if(await cache.match('./offline-ready')){cached=true;ready();}
 }catch(e){if(!cached)status.textContent=`离线准备未完成：${e.message}。请联网刷新重试。`;}
}


