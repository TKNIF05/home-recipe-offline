const CACHE='home-recipe-web-v20-r7';
export async function prepareOffline(status,updateNotice){
 if(!('serviceWorker' in navigator)){status.textContent='此浏览器不支持离线缓存。';return;}
 const hadController=!!navigator.serviceWorker.controller;
 if(hadController)navigator.serviceWorker.addEventListener('controllerchange',()=>location.reload(),{once:true});
 const cache=await caches.open(CACHE);let cached=!!await cache.match('./offline-ready');
 const ready=()=>{status.textContent='离线资源及 PDF 阅读器已就绪 · 网络版 v20';};
 if(cached)ready();else status.textContent='首次准备离线资源，请保持联网…';
 try{
  const reg=await navigator.serviceWorker.register('./sw.js',{updateViaCache:'none'});
  const offer=()=>{updateNotice.hidden=!reg.waiting;};
  const watch=worker=>{if(!worker)return;const check=async()=>{if(worker.state==='installed'||worker.state==='activated'){offer();const complete=await cache.match('./offline-ready');if(complete){cached=true;ready();}}else if(worker.state==='redundant'&&!cached)status.textContent='离线资源下载未完成，请联网刷新重试。';};worker.addEventListener('statechange',check);check();};
  reg.addEventListener('updatefound',()=>watch(reg.installing));watch(reg.installing);offer();
  await reg.update();
  if(await cache.match('./offline-ready')){cached=true;ready();}
  else if(!reg.installing&&!reg.waiting)status.textContent='离线资源未就绪，请联网刷新重试。';
 }catch(e){if(!cached)status.textContent=`离线准备未完成：${e.message}。请联网刷新重试。`;}
}


