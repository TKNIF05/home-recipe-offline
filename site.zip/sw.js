const CACHE='home-recipe-web-v15-r1';
const FILES=['./','./index.html','./style.css','./app.js','./offline.js','./model.js','./storage.js','./backup.js','./drive-update.js','./drive-auth.js','./drive-config.js','./merge.js','./planner.js','./manifest.webmanifest','./icon.svg','./icon-192.png','./icon-512.png','./sample-process.pdf','./viewer.html','./viewer.js','./pdf-assets.json'];
self.addEventListener('install',event=>event.waitUntil((async()=>{
 const lists=['./pdf-assets.json','./shopping-assets.json'];
 const responses=await Promise.all(lists.map(file=>fetch(file,{cache:'reload'})));
 if(responses.some(response=>!response.ok))throw Error('Resource list unavailable');
 const assets=await Promise.all(responses.map(response=>response.clone().json()));
 const c=await caches.open(CACHE);
 await Promise.all(lists.map((file,i)=>c.put(file,responses[i])));
 const files=[...FILES.filter(file=>!lists.includes(file)),'./shopping-adapter.js',...assets.flat()];
 for(let i=0;i<files.length;i+=16){
  await c.addAll(files.slice(i,i+16).map(file=>new Request(new URL(file,self.location.href),{cache:'reload'})));
 }
 // A stale HTML or bootstrap response must not replace the working offline version.
 const checks=[['./','<span class="release-version">v15</span>'],['./index.html','<span class="release-version">v15</span>'],['./offline.js',CACHE]];
 for(const [file,marker] of checks){
  const response=await c.match(file);
  if(!response||!(await response.text()).includes(marker))throw Error('Offline resources are out of date');
 }
 await c.put('./offline-ready',new Response('v15'));
})()));
self.addEventListener('activate',event=>event.waitUntil((async()=>{await self.clients.claim();for(const name of await caches.keys())if(name.startsWith('home-recipe-web-')&&name!==CACHE)await caches.delete(name);})()));
self.addEventListener('fetch',event=>{if(event.request.method!=='GET'||new URL(event.request.url).origin!==self.location.origin)return;event.respondWith(caches.open(CACHE).then(async c=>(await c.match(event.request,{ignoreSearch:['./viewer.html','./shopping/'].some(path=>new URL(event.request.url).pathname===new URL(path,self.location).pathname)}))||fetch(event.request)));});


