const CACHE='home-recipe-web-v25-r1';
const POLICY='home-recipe-update-policy';
const REQUIRE_APPROVAL='./.update-confirmation-required';
const FILES=['./','./index.html','./style.css','./ui-shell.css','./app.js','./offline.js','./model.js','./storage.js','./backup.js','./drive-update.js','./drive-auth.js','./drive-config.js','./merge.js','./planner.js','./household-conversion.js','./nutrition-foods.js','./recipe-nutrition.js','./manifest.webmanifest','./icon.svg','./icon-192.png','./icon-512.png','./sample-process.pdf','./viewer.html','./viewer.js','./pdf-assets.json'];
self.addEventListener('install',event=>event.waitUntil((async()=>{
 const policy=await caches.open(POLICY);
 const approval='./.approve-update/'+CACHE;
 // Existing releases without this policy must first reach the release that offers the button.
 if(self.registration.active && await policy.match(REQUIRE_APPROVAL)){
  const permission=await policy.match(approval);
  if(!permission || !(Number(await permission.text())>Date.now())) throw Error('Update needs user approval');
 }
 const lists=['./pdf-assets.json','./shopping-assets.json'];
 const responses=await Promise.all(lists.map(file=>fetch(file,{cache:'reload'})));
 if(responses.some(response=>!response.ok))throw Error('Resource list unavailable');
 const assets=await Promise.all(responses.map(response=>response.clone().json()));
 const c=await caches.open(CACHE);
 await Promise.all(lists.map((file,i)=>c.put(file,responses[i])));
 const files=[...FILES.filter(file=>!lists.includes(file)),'./shopping-adapter.js',...assets.flat()];
 for(let i=0;i<files.length;i+=16){
  await c.addAll(files.slice(i,i+16).map(file=>new Request(new URL(file,self.location.href),{cache:'reload'})));
 }
 // A stale HTML or bootstrap response must not replace the working offline version.
 const checks=[['./','<span class="release-version">v25</span>'],['./index.html','<span class="release-version">v25</span>'],['./offline.js',CACHE]];
 for(const [file,marker] of checks){
  const response=await c.match(file);
  if(!response||!(await response.text()).includes(marker))throw Error('Offline resources are out of date');
 }
 await c.put('./offline-ready',new Response('v25'));
 await policy.delete(approval);
})()));
self.addEventListener('activate',event=>event.waitUntil((async()=>{
 const policy=await caches.open(POLICY);
 await policy.put(REQUIRE_APPROVAL,new Response('1'));
 await self.clients.claim();
 for(const name of await caches.keys())if(name.startsWith('home-recipe-web-')&&name!==CACHE)await caches.delete(name);
})()));
const shellPaths = new Set(['./', './index.html', './viewer.html', './shopping/'].map(path => new URL(path, self.location).pathname));
self.addEventListener('fetch', event => {
 const url = new URL(event.request.url);
 if (event.request.method !== 'GET' || url.origin !== self.location.origin) return;
 event.respondWith((async () => {
  const cache = await caches.open(CACHE);
  return await cache.match(event.request, {ignoreSearch: shellPaths.has(url.pathname)}) || fetch(event.request);
 })());
});


