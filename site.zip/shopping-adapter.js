import { plannedServings } from './planner.js';

export const RECIPE_INBOX_KEY = 'home-shopping-list:recipe-import-v1';

export function recipeShoppingImport(library, date) {
  const recipes = new Map(library.recipes.map(recipe => [recipe.id, recipe]));
  const checked = new Set(library.shoppingChecked ?? []);
  const items = [];
  for (const entry of library.mealPlan ?? []) {
    if (entry.date !== date) continue;
    const recipe = recipes.get(entry.recipeId);
    if (!recipe) continue;
    for (const [kind, lines] of [['ingredients', recipe.ingredients], ['seasonings', recipe.seasonings]]) {
      for (const line of lines) {
        const key = JSON.stringify([date, line.name.trim(), line.unit.trim()]);
        if (checked.has(key) || line.quantity === 0) continue;
        const value = Number((line.quantity * plannedServings(entry.servings) / recipe.servings).toPrecision(15));
        if (!Number.isFinite(value) || value <= 0) throw Error('材料用量超出可处理范围，请调整菜单。');
        items.push({
          name: line.name.trim(), quantity: {value, unit: line.unit.trim()},
          note: date + ' · ' + entry.meal + ' · ' + recipe.title,
          optional: false, storePolicy: {mode: 'any', storeIds: []},
          source: {type: 'recipe', ref: recipe.id + ':' + line.ingredientId,
            externalRef: entry.id + ':' + kind + ':' + line.id},
        });
      }
    }
  }
  if (!items.length) throw Error('当天没有需要发送的材料。旧清单已勾选的项目会保留完成状态。');
  if (items.length > 500) throw Error('当天材料超过 500 项，请减少本次菜单后分批发送。');
  return {format: 'shopping-import', version: 1, items};
}

export function queueRecipeShopping(library, date) {
  const text = JSON.stringify(recipeShoppingImport(library, date));
  if (new TextEncoder().encode(text).length > 1024 * 1024) throw Error('本次菜单购物资料超过 1 MiB，请分批发送。');
  sessionStorage.setItem(RECIPE_INBOX_KEY, text);
}

