// Public browser credentials only. Never put a client secret or access token here.
export const driveConfig = {
  clientId: '95774873322-1v16nhbod4285ioo9bkmb0946p68cv0j.apps.googleusercontent.com',
  apiKey: 'AIzaSyCGm9ks_2nor1uaotijxUBwnj2OahT4CSI',
  projectNumber: '95774873322',
};
