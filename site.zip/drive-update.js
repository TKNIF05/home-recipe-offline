import {decodeLibrary, MAX_LIBRARY_BACKUP} from './backup.js';

export async function checkDriveUpdate({fileId, accessToken, appliedVersion, signal}) {
  if (!/^[A-Za-z0-9_-]+$/.test(fileId ?? '') || !accessToken) throw Error('请先连接 Google Drive 并选择文件。');
  const url = new URL('https://www.googleapis.com/drive/v3/files/' + fileId);
  async function read(params) {
    url.search = new URLSearchParams(params);
    const response = await fetch(url, {headers: {Authorization: 'Bearer ' + accessToken}, cache: 'no-store', redirect: 'error', signal});
    if (response.status === 401) {
      const error = Error('Google Drive 授权已过期，请重新连接。');
      error.code = 'drive-authorization-expired';
      throw error;
    }
    if (response.status === 429) throw Error('Google Drive 请求较多，请稍后再试。');
    if (!response.ok) throw Error('无法读取共享菜谱，请确认当前账号可以下载。');
    return response;
  }
  const metadata = async () => (await read({fields: 'version,size,trashed,capabilities(canDownload)'})).json();
  const file = await metadata();
  if (file.trashed || !file.capabilities?.canDownload || !/^\d+$/.test(file.version ?? '')) throw Error('共享文件不可下载。');
  if (file.version === appliedVersion) return null;
  const size = Number(file.size);
  if (!Number.isSafeInteger(size) || size < 1 || size > MAX_LIBRARY_BACKUP) throw Error('共享文件大小无效或超过 50 MB。');
  const {body} = await read({alt: 'media'});
  const reader = body.getReader();
  const chunks = [];
  let bytes = 0;
  try {
    while (true) {
      const {done, value} = await reader.read();
      if (done) break;
      bytes += value.byteLength;
      if (bytes > size) {
        await reader.cancel();
        throw Error('下载期间共享文件发生变化，请重新检查。');
      }
      chunks.push(value);
    }
  } finally {
    reader.releaseLock();
  }
  if (bytes !== size || (await metadata()).version !== file.version) throw Error('下载期间共享文件发生变化，请重新检查。');
  return {version: file.version, library: await decodeLibrary(new Blob(chunks))};
}
