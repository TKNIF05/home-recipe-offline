import {validateLibrary,migrateLegacyWorkspace} from './model.js';
const DB_NAME='offline-recipe-proof-v1';
export function readLibrary(db){return new Promise((resolve,reject)=>{
 const t=db.transaction('workspace','readwrite'),s=t.objectStore('workspace');let result,failure;
 const fail=e=>{failure=e;t.abort();};
 const r=s.get('library-v2');r.onsuccess=()=>{try{
  if(r.result!==undefined){result=validateLibrary(r.result);return;}
  const old=s.get('current');old.onsuccess=()=>{try{if(old.result!==undefined){result=migrateLegacyWorkspace(old.result);s.put(result,'library-v2');}}catch(e){fail(e);}};
 }catch(e){fail(e);}};
 t.oncomplete=()=>resolve(result);t.onerror=()=>reject(failure||t.error);t.onabort=()=>reject(failure||t.error||Error('迁移已取消。'));
});}
export function writeLibrary(db,value){validateLibrary(value);return new Promise((resolve,reject)=>{const t=db.transaction('workspace','readwrite');t.objectStore('workspace').put(value,'library-v2');t.oncomplete=resolve;t.onerror=()=>reject(t.error);t.onabort=()=>reject(t.error||Error('保存已取消。'));});}
export async function openStore(){
  return new Promise((resolve,reject)=>{const r=indexedDB.open(DB_NAME,1);r.onupgradeneeded=()=>r.result.createObjectStore('workspace');r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error);r.onblocked=()=>reject(new Error('数据库升级被其他窗口阻止，请关闭其他测试页面。'));});
}
export function read(db){return new Promise((resolve,reject)=>{const r=db.transaction('workspace').objectStore('workspace').get('current');r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error);});}
export function write(db,value){return new Promise((resolve,reject)=>{const t=db.transaction('workspace','readwrite');t.objectStore('workspace').put(value,'current');t.oncomplete=resolve;t.onerror=()=>reject(t.error);t.onabort=()=>reject(t.error||new Error('保存已取消'));});}
