export const meals = ['早餐', '午餐', '晚餐'];

export function plannedServings(value) {
  return Math.ceil(value);
}

export function validatePlan(entries = [], checked = []) {
  const ids = new Set();
  if (!Array.isArray(entries) || entries.some(entry => {
    if (!entry || typeof entry.id !== 'string' || !entry.id || ids.has(entry.id) ||
        !/^\d{4}-\d{2}-\d{2}$/.test(entry.date) ||
        !meals.includes(entry.meal) || typeof entry.recipeId !== 'string' || !entry.recipeId ||
        !Number.isFinite(entry.servings) || entry.servings < 0.1 || entry.servings > 100) return true;
    const date = new Date(entry.date);
    if (!Number.isFinite(date.getTime()) || date.toISOString().slice(0, 10) !== entry.date) return true;
    ids.add(entry.id);
    return false;
  }) || !Array.isArray(checked) || checked.some(key => typeof key !== 'string')) {
    throw Error('菜单或购物勾选资料无效。');
  }
}

export function shoppingForDate(library, date) {
  const recipes = new Map(library.recipes.map(recipe => [recipe.id, recipe]));
  const items = new Map();
  for (const entry of library.mealPlan ?? []) {
    if (entry.date !== date) continue;
    const recipe = recipes.get(entry.recipeId);
    if (!recipe) continue;
    for (const line of [...recipe.ingredients, ...recipe.seasonings]) {
      const key = JSON.stringify([date, line.name.trim(), line.unit.trim()]);
      const item = items.get(key) ?? {key, name: line.name.trim(), unit: line.unit.trim(), quantity: 0};
      item.quantity = Number((item.quantity +
        line.quantity * (plannedServings(entry.servings) / recipe.servings)).toPrecision(15));
      items.set(key, item);
    }
  }
  return [...items.values()];
}
