// USDA FoodData Central SR Legacy, published 2019-04-01.
// Values are per 100 g of edible food. Energy in kcal, sodium in mg, others in g.
export const nutritionFoods = [
  { id: '171287', label: '全鸡蛋（生，去壳）', values: { kcal: 143, protein: 12.56, fat: 9.51, carbs: 0.72, sodium: 142, sugar: 0.37 } },
  { id: '170026', label: '土豆（生，带皮）', values: { kcal: 77, protein: 2.05, fat: 0.09, carbs: 17.49, sodium: 6, sugar: 0.82 } },
  { id: '171413', label: '橄榄油（烹调或沙拉用）', values: { kcal: 884, protein: 0, fat: 100, carbs: 0, sodium: 2, sugar: 0 } },
  { id: '173627', label: '鸡腿肉（生，仅肉）', values: { kcal: 121, protein: 19.66, fat: 4.12, carbs: 0, sodium: 95, sugar: 0 } },
  { id: '171077', label: '鸡胸肉（生，去皮去骨）', values: { kcal: 120, protein: 22.5, fat: 2.62, carbs: 0, sodium: 45, sugar: 0 } },
  { id: '168877', label: '长粒白米（生，强化）', values: { kcal: 365, protein: 7.13, fat: 0.66, carbs: 79.95, sodium: 5, sugar: 0.12 } },
];
