import {prepareOffline} from './offline.js';
import {openStore,readLibrary,writeLibrary,readRestoreSnapshot} from './storage.js';
import {sample,validateRecipe,migrateLegacyWorkspace,singleWorkspace} from './model.js';
import {checkPdf,decodeLibrary,encodeLibrary,download} from './backup.js';
const $=id=>document.getElementById(id);let db,library,data,pdfURL,pending,busy=false;
async function saveLibrary(next, keepRestoreSnapshot = false) {
  library = await writeLibrary(db, next, {expected: library, keepRestoreSnapshot});
}
async function write(value) {
  if (!library) return saveLibrary(migrateLegacyWorkspace(value));
  const oldAttachment = data.recipe.instructionsAttachmentId;
  const recipes = library.recipes.map(recipe => recipe.id === value.recipe.id ? value.recipe : recipe);
  const attachments = library.attachments.filter(attachment =>
    attachment.id !== value.attachment.id &&
    (attachment.id !== oldAttachment || recipes.some(recipe => recipe.instructionsAttachmentId === oldAttachment)));
  await saveLibrary({...library, recipes, attachments: [...attachments, value.attachment]});
}
async function downloadLibrary(value, prefix) {
  download(await encodeLibrary(value), prefix + '-' + new Date().toISOString().replace(/[:.]/g,'-') + '.json');
}
function message(text,error=false){$('message').textContent=text;$('message').classList.toggle('error',error);}
function appendLine(container, line = {}) {
  const row = document.createElement('div');
  const fields = [['name', '名称', 80], ['quantity', '用量'], ['unit', '单位', 40]];
  for (const [key, title, limit] of fields) {
    const label = document.createElement('label');
    label.textContent = title;
    const input = document.createElement('input');
    input.dataset.field = key;
    input.value = line[key] ?? '';
    input.required = true;
    if (limit) input.maxLength = limit;
    else {
      input.type = 'number';
      input.min = '0';
      input.step = 'any';
    }
    label.append(input);
    row.append(label);
  }
  row.line = line;
  const remove = document.createElement('button');
  remove.type = 'button';
  remove.textContent = '移除此行';
  remove.onclick = () => row.remove();
  row.append(remove);
  container.append(row);
}
function readLines(container) {
  return Array.from(container.children, row => {
    const value = key => row.querySelector('[data-field="' + key + '"]').value.trim();
    const name = value('name');
    const unit = value('unit');
    const quantity = value('quantity');
    if (!name || !unit || !quantity) throw Error('请填完整材料和调料的名称、用量及单位。');
    const previous = row.line;
    return {
      id: previous.id ?? crypto.randomUUID(),
      ingredientId: name === previous.name ? previous.ingredientId : crypto.randomUUID(),
      unitId: unit === previous.unit ? previous.unitId : crypto.randomUUID(),
      name, unit, quantity: Number(quantity),
    };
  });
}
$('addIngredient').onclick = () => appendLine($('ingredientsEdit'));
$('addSeasoning').onclick = () => appendLine($('seasoningsEdit'));
function renderRecipeList() {
  const list = $('recipeList');
  const query = $('recipeSearch').value.trim().toLocaleLowerCase();
  const matches = library.recipes.filter(recipe => recipe.title.toLocaleLowerCase().includes(query));
  const options = matches.map(recipe => new Option(recipe.title, recipe.id));
  const selectedId = data?.recipe.id;
  if (!matches.some(recipe => recipe.id === selectedId)) {
    const placeholder = new Option(matches.length ? '请选择菜谱' : '没有匹配的菜谱', '');
    placeholder.disabled = true;
    options.unshift(placeholder);
  }
  list.replaceChildren(...options);
  list.value = matches.some(recipe => recipe.id === selectedId) ? selectedId : '';
  list.disabled = matches.length === 0;
  $('recipeSearchStatus').textContent = query ? '找到 ' + matches.length + ' 条菜谱' : '';
}
$('recipeSearch').oninput = () => {
  if (library) renderRecipeList();
};
function render(){
 renderRecipeList();
 $('editForm').closest('article').hidden = !data;
 if (!data) {
   if (pdfURL) URL.revokeObjectURL(pdfURL);
   pdfURL = null;
   return;
 }

 const r=data.recipe;
 for (const key of ['ingredients', 'seasonings']) {
   const container = $(key + 'Edit');
   container.replaceChildren();
   for (const line of r[key]) appendLine(container, line);
 }$('recipeTitle').textContent=r.title;$('recipeMeta').textContent=`${r.servings} 人份 · 原始家庭单位`;$('notes').textContent=r.notes;for(const k of ['ingredients','seasonings']){$(k).replaceChildren(...r[k].map(x=>{const li=document.createElement('li'),n=document.createElement('span'),q=document.createElement('span');n.textContent=x.name;q.textContent=`${x.quantity} ${x.unit}`;li.append(n,q);return li;}));}$('titleInput').value=r.title;$('servingsInput').value=r.servings;$('notesInput').value=r.notes;$('recordInfo').textContent=`菜谱 ID：${r.id} ｜ 附件 ID：${r.instructionsAttachmentId}\n本机保存时间：${new Date(r.updatedAt).toLocaleString('zh-CN')}`;$('pdfName').textContent=`${data.attachment.name} · ${Math.ceil(data.attachment.blob.size/1024)} KB`;if(pdfURL)URL.revokeObjectURL(pdfURL);pdfURL=URL.createObjectURL(data.attachment.blob);for(const id of ['openPdf','downloadPdf']){$(id).href=id==='openPdf'?'./viewer.html?recipeId='+encodeURIComponent(r.id):pdfURL;$(id).hidden=false;}$('downloadPdf').download=data.attachment.name;$('dbStatus').textContent='已保存到本机 IndexedDB';}
async function action(fn){if(busy)return;busy=true;document.querySelectorAll('button').forEach(b=>b.disabled=true);try{await fn();}catch(e){message(`操作未完成：${e.message}`,true);}finally{busy=false;document.querySelectorAll('button').forEach(b=>b.disabled=false);}}
async function persistStatus(){$('persistStatus').textContent=navigator.storage?.persisted?((await navigator.storage.persisted())?'已获持久存储权限；仍建议外部备份。':'尚未获持久存储权限。'):'此浏览器不提供持久存储状态查询。';}
async function offline(){await prepareOffline($('offlineStatus'),$('applyUpdate'));}

async function init(){try{if(!isSecureContext)throw new Error('请从已发布的 HTTPS 地址打开应用，不要直接双击 HTML。');db=await openStore();library=await readLibrary(db);data=library===undefined?undefined:library.recipes.length ? singleWorkspace(library,library.recipes[0].id) : null;if(!library){const res=await fetch('./sample-process.pdf');if(!res.ok)throw new Error('示例 PDF 加载失败');const blob=await res.blob();await checkPdf(blob);const initial=sample(blob);await write(initial);data=initial;}render();message(data ? '菜谱和 PDF 已保存在本机。' : '菜谱库为空，可以新增菜谱。');await persistStatus();offline();}catch(e){message(`启动失败：${e.message}`,true);$('dbStatus').textContent='尚未完成本地保存';}}
$('editForm').onsubmit=e=>{e.preventDefault();action(async()=>{if(!data)throw new Error('数据库尚未就绪');const next=structuredClone(data);next.recipe.title=$('titleInput').value.trim();next.recipe.servings=Number($('servingsInput').value);next.recipe.notes=$('notesInput').value;next.recipe.ingredients=readLines($('ingredientsEdit'));next.recipe.seasonings=readLines($('seasoningsEdit'));next.recipe.updatedAt=new Date().toISOString();validateRecipe(next.recipe);await write(next);data=next;render();message('修改已保存到本机，刷新后仍会保留。');});};
$('pdfInput').onchange=e=>{const f=e.target.files[0];e.target.value='';if(f)action(async()=>{if(!data)throw new Error('数据库尚未就绪');await checkPdf(f);const next=structuredClone(data);next.attachment={id:crypto.randomUUID(),name:f.name,mime:'application/pdf',blob:new Blob([await f.arrayBuffer()],{type:'application/pdf'})};next.recipe.instructionsAttachmentId=next.attachment.id;next.recipe.updatedAt=new Date().toISOString();await write(next);data=next;render();message('新的 PDF 已保存在本机，并关联到原菜谱 ID。');});};
$('export').onclick=()=>action(async()=>{if(!library)throw new Error('数据库尚未就绪');await downloadLibrary(await readLibrary(db),'recipe-library');message('已发起备份下载。请检查下载文件；其中包含完整 PDF。');});
$('exportRestoreSnapshot').onclick = () => action(async () => {
  if (!db) throw Error('数据库尚未就绪');
  const snapshot = await readRestoreSnapshot(db);
  if (!snapshot) throw Error('本机还没有恢复前快照。');
  await downloadLibrary(snapshot, 'before-restore');
  message('已发起恢复前快照下载，可用下载的 JSON 恢复。');
});
$('import').onchange=e=>{const f=e.target.files[0];e.target.value='';if(f)action(async()=>{pending=null;$('importPreview').hidden=true;pending = await decodeLibrary(f);
$('previewText').textContent = '将替换本机菜谱库，恢复 ' + pending.recipes.length + ' 条菜谱和 ' + pending.attachments.length + ' 个 PDF：' + pending.recipes.map(recipe => recipe.title).join('、');
$('importPreview').hidden=false;message('校验通过，尚未修改本机资料。请检查恢复预览。');});};
$('cancelImport').onclick=()=>{pending=null;$('importPreview').hidden=true;message('已取消恢复，本机资料未变。');};
$('confirmImport').onclick=()=>action(async()=>{if(!pending||!library)throw new Error('请先选择有效备份');await downloadLibrary(library,'before-restore');await saveLibrary(pending,true);$('recipeSearch').value='';data=library.recipes.length?singleWorkspace(library,library.recipes[0].id):null;pending=null;render();$('importPreview').hidden=true;message('备份已恢复，菜谱和 PDF 已写入本机。请确认恢复前备份已下载。');});
$('persist').onclick=()=>action(async()=>{if(!navigator.storage?.persist)throw new Error('此浏览器不支持主动申请');await navigator.storage.persist();await persistStatus();message('已查询持久保存结果。外部备份仍需保留。');});
$('deleteRecipe').onclick = () => action(async () => {
  if (!data || !library) return;
  const current = data.recipe;
  if (!confirm('删除「' + current.title + '」？如需保留，请先取消并导出全库备份。')) return;
  const recipes = library.recipes.filter(recipe => recipe.id !== current.id);
  const attachments = library.attachments.filter(attachment =>
    attachment.id !== current.instructionsAttachmentId ||
    recipes.some(recipe => recipe.instructionsAttachmentId === attachment.id));
  await saveLibrary({...library, recipes, attachments});
  data = recipes.length ? singleWorkspace(library, recipes[0].id) : null;
  render();
  message(recipes.length ? '菜谱已删除。' : '菜谱库已清空，可以新增菜谱。');
});
$('recipeList').onchange = () => {
  if (busy || !library || !$('recipeList').value) return;
  data = singleWorkspace(library, $('recipeList').value);
  render();
};
$('addRecipe').onsubmit = event => {
  event.preventDefault();
  action(async () => {
    if (!library) throw Error('数据库尚未就绪');
    const title = $('newTitle').value.trim();
    const file = $('newPdf').files[0];
    if (!title || !file) throw Error('请输入菜谱名称并选择 PDF。');
    await checkPdf(file);
    const now = new Date().toISOString();
    const attachment = {id: crypto.randomUUID(), name: file.name, mime: 'application/pdf', blob: file};
    const recipe = {id: crypto.randomUUID(), title, servings: 2, notes: '',
      createdAt: now, updatedAt: now, instructionsAttachmentId: attachment.id,
      ingredients: [], seasonings: []};
    await saveLibrary({...library, recipes: [...library.recipes, recipe], attachments: [...library.attachments, attachment]});
    data = singleWorkspace(library, recipe.id);
    $('addRecipe').reset();
    $('recipeSearch').value = '';
    render();
    message('新菜谱已保存在本机。');
  });
};
init();
