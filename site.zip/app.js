import {driveConfig} from './drive-config.js';
import {prepareDrive,authorizeDrive,chooseDriveFile} from './drive-auth.js';
import {checkDriveUpdate} from './drive-update.js';
import {meals,shoppingForDate,plannedServings} from './planner.js';
import {queueRecipeShopping} from './shopping-adapter.js';
import {previewMerge,mergeLibraries,recordLocalRevision} from './merge.js';
import {prepareOffline} from './offline.js';
import {setupHouseholdConversion} from './household-conversion.js';
import {openStore,readLibrary,writeLibrary,readRestoreSnapshot} from './storage.js';
import {sample,validateRecipe,migrateLegacyWorkspace,singleWorkspace} from './model.js';
import {checkPdf,decodeLibrary,encodeLibrary,download,checkLibraryBackupSize} from './backup.js';
let driveReady = false, driveSession, drivePending, driveApplied;
let driveFileId = '';
try { driveFileId = localStorage.getItem('recipe:drive-file') ?? ''; } catch {}
const $=id=>document.getElementById(id);let db,library,data,pdfURL,pending,busy=false;
const renderConversion = setupHouseholdConversion($('toggleConversion'), $('conversionForm'));
async function saveLibrary(next, keepRestoreSnapshot = false) {
  library = await writeLibrary(db, next, {expected: library, keepRestoreSnapshot});
}
async function write(value) {
  if (!library) return saveLibrary(migrateLegacyWorkspace(value));
  const oldAttachment = data.recipe.instructionsAttachmentId;
  const recipes = library.recipes.map(recipe => recipe.id === value.recipe.id ? value.recipe : recipe);
  const attachments = library.attachments.filter(attachment =>
    attachment.id !== value.attachment.id &&
    (attachment.id !== oldAttachment || recipes.some(recipe => recipe.instructionsAttachmentId === oldAttachment)));
  const next = {...library, recipes, attachments: [...attachments, value.attachment]};
  checkLibraryBackupSize(next);
  await saveLibrary(recordLocalRevision(next, value.recipe.id));
}
async function downloadLibrary(value, prefix) {
  download(await encodeLibrary(value), prefix + '-' + new Date().toISOString().replace(/[:.]/g,'-') + '.json');
}
function message(text,error=false){$('message').textContent=text;$('message').classList.toggle('error',error);}
function appendLine(container, line = {}) {
  const row = document.createElement('div');
  const fields = [['name', '名称', 80], ['quantity', '用量'], ['unit', '单位', 40]];
  for (const [key, title, limit] of fields) {
    const label = document.createElement('label');
    label.textContent = title;
    const input = document.createElement('input');
    input.dataset.field = key;
    input.value = line[key] ?? '';
    input.required = true;
    if (limit) input.maxLength = limit;
    else {
      input.type = 'number';
      input.min = '0';
      input.step = 'any';
    }
    label.append(input);
    row.append(label);
  }
  row.line = line;
  const remove = document.createElement('button');
  remove.type = 'button';
  remove.textContent = '移除此行';
  remove.onclick = () => row.remove();
  row.append(remove);
  container.append(row);
}
function readLines(container) {
  return Array.from(container.children, row => {
    const value = key => row.querySelector('[data-field="' + key + '"]').value.trim();
    const name = value('name');
    const unit = value('unit');
    const quantity = value('quantity');
    if (!name || !unit || !quantity) throw Error('请填完整材料和调料的名称、用量及单位。');
    const previous = row.line;
    return {
      id: previous.id ?? crypto.randomUUID(),
      ingredientId: name === previous.name ? previous.ingredientId : crypto.randomUUID(),
      unitId: unit === previous.unit ? previous.unitId : crypto.randomUUID(),
      name, unit, quantity: Number(quantity),
    };
  });
}
$('addIngredient').onclick = () => appendLine($('ingredientsEdit'));
$('addSeasoning').onclick = () => appendLine($('seasoningsEdit'));
function renderRecipeList() {
  const list = $('recipeList');
  const query = $('recipeSearch').value.trim().toLocaleLowerCase();
  const matches = library.recipes.filter(recipe => [recipe.title, recipe.category ?? ''].some(value => value.toLocaleLowerCase().includes(query)));
  const selectedId = data?.recipe.id;
  list.replaceChildren(...matches.map(recipe => {
    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'button secondary recipe-choice';
    button.dataset.recipeId = recipe.id;
    button.setAttribute('aria-pressed', String(recipe.id === selectedId));
    button.textContent = recipe.title;
    if (recipe.category) {
      const category = document.createElement('small');
      category.textContent = recipe.category;
      button.append(category);
    }
    return button;
  }));
  $('recipeSearchStatus').textContent = matches.length
    ? (query ? '找到 ' + matches.length + ' 条菜谱' : '')
    : (query ? '没有匹配的菜谱。' : '菜谱库为空。');
}
$('recipeSearch').oninput = () => {
  if (library) renderRecipeList();
};
function render(){
 renderRecipeList();
 renderPlan();
 renderConversion(data?.recipe);
 $('editForm').closest('article').hidden = !data;
 if (!data) {
   if (pdfURL) URL.revokeObjectURL(pdfURL);
   pdfURL = null;
   return;
 }

 const r=data.recipe;
 for (const key of ['ingredients', 'seasonings']) {
   const container = $(key + 'Edit');
   container.replaceChildren();
   for (const line of r[key]) appendLine(container, line);
 }$('recipeTitle').textContent=r.title;$('recipeMeta').textContent=`${r.servings} 人份 · 原始家庭单位`;$('notes').textContent=r.notes;for(const k of ['ingredients','seasonings']){$(k).replaceChildren(...r[k].map(x=>{const li=document.createElement('li'),n=document.createElement('span'),q=document.createElement('span');n.textContent=x.name;q.textContent=`${x.quantity} ${x.unit}`;li.append(n,q);return li;}));}$('titleInput').value=r.title;$('categoryInput').value=r.category??'';$('servingsInput').value=r.servings;$('notesInput').value=r.notes;$('recordInfo').textContent=`菜谱 ID：${r.id} ｜ 附件 ID：${r.instructionsAttachmentId}\n本机保存时间：${new Date(r.updatedAt).toLocaleString('zh-CN')}`;$('pdfName').textContent=`${data.attachment.name} · ${Math.ceil(data.attachment.blob.size/1024)} KB`;if(pdfURL)URL.revokeObjectURL(pdfURL);pdfURL=URL.createObjectURL(data.attachment.blob);for(const id of ['openPdf','downloadPdf']){$(id).href=id==='openPdf'?'./viewer.html?recipeId='+encodeURIComponent(r.id):pdfURL;$(id).hidden=false;}$('downloadPdf').download=data.attachment.name;$('dbStatus').textContent='已保存到本机 IndexedDB';}
async function action(fn){if(busy)return;busy=true;document.querySelectorAll('button').forEach(b=>b.disabled=true);try{await fn();}catch(e){message(`操作未完成：${e.message}`,true);}finally{busy=false;document.querySelectorAll('button').forEach(b=>b.disabled=false);}}
async function persistStatus(){$('persistStatus').textContent=navigator.storage?.persisted?((await navigator.storage.persisted())?'已获持久存储权限；仍建议外部备份。':'尚未获持久存储权限。'):'此浏览器不提供持久存储状态查询。';}
async function offline(){await prepareOffline($('offlineStatus'),$('applyUpdate'));}

async function init(){try{if(!isSecureContext)throw new Error('请从已发布的 HTTPS 地址打开应用，不要直接双击 HTML。');db=await openStore();library=await readLibrary(db);if(library){
  const returnId=new URLSearchParams(location.hash.slice(1)).get('recipeId');
  const recipe=library.recipes.find(item=>item.id===returnId) ?? library.recipes[0];
  data=recipe ? singleWorkspace(library,recipe.id) : null;
}if(!library){const res=await fetch('./sample-process.pdf');if(!res.ok)throw new Error('示例 PDF 加载失败');const blob=await res.blob();await checkPdf(blob);const initial=sample(blob);await write(initial);data=initial;}render();message(data ? '菜谱和 PDF 已保存在本机。' : '菜谱库为空，可以新增菜谱。');await persistStatus();offline();}catch(e){message(`启动失败：${e.message}`,true);$('dbStatus').textContent='尚未完成本地保存';}}
$('editForm').onsubmit=e=>{e.preventDefault();action(async()=>{if(!data)throw new Error('数据库尚未就绪');const next=structuredClone(data);next.recipe.title=$('titleInput').value.trim();next.recipe.category=$('categoryInput').value.trim();next.recipe.servings=Number($('servingsInput').value);next.recipe.notes=$('notesInput').value;next.recipe.ingredients=readLines($('ingredientsEdit'));next.recipe.seasonings=readLines($('seasoningsEdit'));next.recipe.updatedAt=new Date().toISOString();validateRecipe(next.recipe);await write(next);data=next;render();message('修改已保存到本机，刷新后仍会保留。');});};
$('pdfInput').onchange=e=>{const f=e.target.files[0];e.target.value='';if(f)action(async()=>{if(!data)throw new Error('数据库尚未就绪');await checkPdf(f);const next=structuredClone(data);next.attachment={id:crypto.randomUUID(),name:f.name,mime:'application/pdf',blob:new Blob([await f.arrayBuffer()],{type:'application/pdf'})};next.recipe.instructionsAttachmentId=next.attachment.id;next.recipe.updatedAt=new Date().toISOString();await write(next);data=next;render();message('新的 PDF 已保存在本机，并关联到原菜谱 ID。');});};
$('export').onclick=()=>action(async()=>{if(!library)throw new Error('数据库尚未就绪');const latest = await readLibrary(db);
const tracked = new Set((latest.revisions ?? []).map(revision => revision.id));
if ([...latest.recipes.map(recipe => recipe.id), ...(latest.deletedRecipeIds ?? [])].some(id => !tracked.has(id))) {
  await saveLibrary(recordLocalRevision(latest));
  await downloadLibrary(library,'recipe-library');
} else {
  await downloadLibrary(latest,'recipe-library');
}message('已发起备份下载。请检查下载文件；其中包含完整 PDF。');});
$('exportRestoreSnapshot').onclick = () => action(async () => {
  if (!db) throw Error('数据库尚未就绪');
  const snapshot = await readRestoreSnapshot(db);
  if (!snapshot) throw Error('本机还没有恢复前快照。');
  await downloadLibrary(snapshot, 'before-restore');
  message('已发起恢复前快照下载，可用下载的 JSON 恢复。');
});
async function showImportPreview(incoming, driveUpdate = null) {
pending=null;
$('importPreview').hidden=true;
const rows = await previewMerge(library, incoming);
$('mergePreview').replaceChildren();
const counts = document.createElement('p');
counts.textContent = '合并预览：新增 ' + rows.filter(row => row.status === 'new').length +
  ' 条，自动更新 ' + rows.filter(row => row.status === 'update').length + ' 条，跳过旧版本 ' + rows.filter(row => row.status === 'older').length + ' 条，相同 ' + rows.filter(row => row.status === 'unchanged').length + ' 条，新增删除记录 ' + rows.filter(row => row.status === 'deletion').length + ' 条。';
$('mergePreview').append(counts);
for (const row of rows.filter(row => row.status === 'conflict')) {
  const label = document.createElement('label');
  label.textContent = '本机「' + row.localTitle + '」与导入「' + row.title + '」有差异';
  const select = document.createElement('select');
  select.dataset.recipeId = row.id;
  select.append(new Option('请选择版本',''),new Option('保留本机','local'),new Option('使用导入','incoming'));
  label.append(select);
  $('mergePreview').append(label);
}
const summary = incoming.recipes.length + ' 条菜谱和 ' + incoming.attachments.length + ' 个 PDF：' + incoming.recipes.map(recipe => recipe.title).join('、');
$('previewText').textContent = (driveUpdate ? '共享文件包含 ' : '将替换本机菜谱库，恢复 ') + summary;
$('restoreHint').hidden = $('confirmImport').hidden = Boolean(driveUpdate);
pending = incoming;
drivePending = driveUpdate;
$('importPreview').hidden = false;
message(driveUpdate ? '已读取共享菜谱，请检查预览后合并。' : '校验通过，尚未修改本机资料。请检查恢复预览。');
}
$('import').onchange = event => {
  const file = event.target.files[0];
  event.target.value = '';
  if (file) action(async () => {
    drivePending = null;
    pending = null;
    $('importPreview').hidden = true;
    await showImportPreview(await decodeLibrary(file));
  });
};
$('cancelImport').onclick=()=>{drivePending=null;pending=null;$('importPreview').hidden=true;message('已取消恢复，本机资料未变。');};
$('confirmMerge').onclick = () => action(async () => {
  if (!pending || !library) throw Error('请先选择有效备份。');
  const choices = new Map(Array.from($('mergePreview').querySelectorAll('select'),
    select => [select.dataset.recipeId, select.value]));
  const merged = await mergeLibraries(library, pending, choices);
  checkLibraryBackupSize(merged);
  await saveLibrary(merged, true);
  if (drivePending) driveApplied = {...drivePending, writeToken: library.writeToken};
  drivePending = null;
  const id = library.recipes.find(recipe => recipe.id === data?.recipe.id)?.id ?? library.recipes[0]?.id;
  data = id ? singleWorkspace(library, id) : null;
  $('recipeSearch').value = '';
  pending = null;
  $('importPreview').hidden = true;
  render();
  message('合并完成。可以下载合并前的快照。');
});
$('confirmImport').onclick=()=>action(async()=>{if(!pending||!library||drivePending)throw new Error('请先选择有效的本机备份');await downloadLibrary(library,'before-restore');await saveLibrary(pending,true);$('recipeSearch').value='';data=library.recipes.length?singleWorkspace(library,library.recipes[0].id):null;pending=null;render();$('importPreview').hidden=true;message('备份已恢复，菜谱和 PDF 已写入本机。请确认恢复前备份已下载。');});
$('persist').onclick=()=>action(async()=>{if(!navigator.storage?.persist)throw new Error('此浏览器不支持主动申请');await navigator.storage.persist();await persistStatus();message('已查询持久保存结果。外部备份仍需保留。');});
$('deleteRecipe').onclick = () => action(async () => {
  if (!data || !library) return;
  const current = data.recipe;
  if (!confirm('删除「' + current.title + '」？如需保留，请先取消并导出全库备份。')) return;
  const recipes = library.recipes.filter(recipe => recipe.id !== current.id);
  const attachments = library.attachments.filter(attachment =>
    attachment.id !== current.instructionsAttachmentId ||
    recipes.some(recipe => recipe.instructionsAttachmentId === attachment.id));
  await saveLibrary(recordLocalRevision({...library, recipes, attachments, deletedRecipeIds: [...(library.deletedRecipeIds ?? []), current.id]}, current.id));
  data = recipes.length ? singleWorkspace(library, recipes[0].id) : null;
  render();
  message(recipes.length ? '菜谱已删除。' : '菜谱库已清空，可以新增菜谱。');
});
$('recipeList').onclick = event => {
  const button = event.target.closest('button[data-recipe-id]');
  if (busy || !library || !button) return;
  data = singleWorkspace(library, button.dataset.recipeId);
  render();
  $('recipeList').querySelector('[aria-pressed="true"]').focus({preventScroll:true});
};
$('addRecipe').onsubmit = event => {
  event.preventDefault();
  action(async () => {
    if (!library) throw Error('数据库尚未就绪');
    const title = $('newTitle').value.trim();
    const file = $('newPdf').files[0];
    if (!title || !file) throw Error('请输入菜谱名称并选择 PDF。');
    await checkPdf(file);
    const now = new Date().toISOString();
    const attachment = {id: crypto.randomUUID(), name: file.name, mime: 'application/pdf', blob: file};
    const recipe = {id: crypto.randomUUID(), title, servings: 2, notes: '',
      createdAt: now, updatedAt: now, instructionsAttachmentId: attachment.id,
      ingredients: [], seasonings: []};
    const next = {...library, recipes: [...library.recipes, recipe], attachments: [...library.attachments, attachment]};
    checkLibraryBackupSize(next);
    await saveLibrary(recordLocalRevision(next, recipe.id));
    data = singleWorkspace(library, recipe.id);
    $('addRecipe').reset();
    $('recipeSearch').value = '';
    render();
    message('新菜谱已保存在本机。');
  });
};
const today = new Date();
$('planDate').value = new Date(today.getTime() - today.getTimezoneOffset() * 60000).toISOString().slice(0, 10);
$('planDate').onchange = () => { if (library) renderPlan(); };

function renderPlan() {
  const selected = $('planRecipe').value;
  const names = new Map(library.recipes.map(recipe => [recipe.id, recipe.title]));
  $('planRecipe').replaceChildren(...library.recipes.map(recipe => new Option(recipe.title, recipe.id)));
  if (names.has(selected)) $('planRecipe').value = selected;
  const date = $('planDate').value;
  const entries = (library.mealPlan ?? []).filter(entry => entry.date === date);
  const items = shoppingForDate(library, date);
  const groups = [];
  const mealIcons = ['☕', '🍱', '🍲'];
  for (const [index, meal] of meals.entries()) {
    const dishes = entries.filter(entry => entry.meal === meal);
    if (!dishes.length) continue;
    const group = document.createElement('section');
    group.className = 'meal-group';
    const heading = document.createElement('h4');
    const mealIcon = document.createElement('span');
    mealIcon.className = 'meal-icon';
    mealIcon.setAttribute('aria-hidden', 'true');
    mealIcon.textContent = mealIcons[index];
    heading.append(mealIcon, meal);
    const rows = document.createElement('ul');
    for (const entry of dishes) {
      const row = document.createElement('li');
      const name = names.get(entry.recipeId) ?? '菜谱已删除或不可用';
      const title = document.createElement('span');
      const dishIcon = document.createElement('span');
      dishIcon.className = 'dish-icon';
      dishIcon.setAttribute('aria-hidden', 'true');
      dishIcon.textContent = '🍽️';
      title.append(dishIcon, name + ' · ' + plannedServings(entry.servings) + ' 人份');
      const remove = document.createElement('button');
      remove.type = 'button';
      remove.className = 'button secondary';
      remove.textContent = '移除';
      remove.setAttribute('aria-label', '移除' + meal + '的' + name);
      remove.onclick = () => updatePlan({...library, mealPlan: library.mealPlan.filter(item => item.id !== entry.id)});
      row.append(title, remove);
      rows.append(row);
    }
    group.append(heading, rows);
    groups.push(group);
  }
  $('plannedMeals').replaceChildren(...groups);
  $('shoppingItems').replaceChildren(...items.map(item => {
    const row = document.createElement('li');
    const label = document.createElement('label');
    const legacyChecked = (library.shoppingChecked ?? []).includes(item.key);
    label.textContent = item.name + ' ' + new Intl.NumberFormat('zh-CN', {maximumSignificantDigits: 8}).format(item.quantity) +
      ' ' + item.unit + (legacyChecked ? '（原清单已勾选）' : '');
    row.append(label);
    return row;
  }));
  $('planStatus').textContent = entries.length ? '' : '当天还没有排菜。';
  $('sendShopping').disabled = !items.some(item => !(library.shoppingChecked ?? []).includes(item.key) && item.quantity > 0);
}

function updatePlan(next) {
  action(async () => {
    try {
      checkLibraryBackupSize(next);
      await saveLibrary(next);
    } catch (error) {
      renderPlan();
      $('planStatus').textContent = error.message;
      return;
    }
    renderPlan();
  });
}

$('mealForm').onsubmit = event => {
  event.preventDefault();
  if (!library || !library.recipes.some(recipe => recipe.id === $('planRecipe').value)) return;
  const entry = {id: crypto.randomUUID(), date: $('planDate').value, meal: $('planMeal').value,
    recipeId: $('planRecipe').value, servings: plannedServings(Number($('planServings').value))};
  updatePlan({...library, mealPlan: [...(library.mealPlan ?? []), entry]});
};
$('sendShopping').onclick = () => {
  try {
    queueRecipeShopping(library, $('planDate').value);
    location.href = './shopping/?from=recipe';
  } catch (error) {
    $('planStatus').textContent = error.message;
  }
};
const driveConfigured = Boolean(driveConfig.clientId && driveConfig.apiKey && driveConfig.projectNumber);

function warmDrive() {
  if (!driveConfigured || driveReady || !navigator.onLine) return;
  const status = $('driveStatus');
  status.textContent = '正在加载 Google Drive…';
  prepareDrive().then(() => {
    driveReady = true;
    status.textContent = 'Google Drive 已就绪。';
  }).catch(error => {
    status.textContent = error.message;
  });
}

function driveClick(selectFile) {
  if (!driveConfigured) {
    message('Google Drive 连接尚待配置完成。');
    return;
  }
  if (!navigator.onLine) { message('联网后可检查 Google Drive 更新。'); return; }
  if (!driveReady) {
    warmDrive();
    return;
  }
  action(async () => {
    drivePending = null;
    pending = null;
    $('importPreview').hidden = true;
    if (!driveSession || Date.now() >= driveSession.expiresAt || selectFile) {
      driveSession = undefined;
      driveSession = await authorizeDrive(driveConfig);
    }
    if (selectFile || !driveFileId) {
      const chosen = await chooseDriveFile(driveConfig, driveSession.token);
      if (!chosen) { message('已取消文件选择。'); return; }
      driveFileId = chosen;
      driveApplied = null;
      try { localStorage.setItem('recipe:drive-file', chosen); } catch {}
    }
    const appliedVersion = driveApplied?.fileId === driveFileId &&
      driveApplied.writeToken === library.writeToken ? driveApplied.version : undefined;
    let update;
    try {
      update = await checkDriveUpdate({fileId: driveFileId, accessToken: driveSession.token,
        appliedVersion, signal: AbortSignal.timeout(60000)});
    } catch (error) {
      if (error.code === 'drive-authorization-expired') driveSession = undefined;
      if (error.name === 'TimeoutError') throw Error('共享菜谱下载超时，请稍后重试。');
      throw error;
    }
    if (!update) { message('已检查，共享菜谱版本未变化。'); return; }
    await showImportPreview(update.library, {fileId: driveFileId, version: update.version});
  });
}
$('connectDrive').onclick = () => driveClick(true);
$('checkDrive').onclick = () => driveClick(false);
window.addEventListener('online', warmDrive);
warmDrive();
init();
