import {validateRecipe,validateLibrary,migrateLegacyWorkspace} from './model.js';
export const MAX_PDF=10*1024*1024;
export async function checkPdf(blob){if(!blob.size||blob.size>MAX_PDF)throw new Error('请选择不超过 10 MB 的 PDF。');if(await blob.slice(0,5).text()!=='%PDF-')throw new Error('文件不是有效的 PDF 格式。');}
async function digest(blob){return [...new Uint8Array(await crypto.subtle.digest('SHA-256',await blob.arrayBuffer()))].map(x=>x.toString(16).padStart(2,'0')).join('');}
async function encodeAttachment(attachment){
 const data={attachment};const url=await new Promise((resolve,reject)=>{const r=new FileReader();r.onload=()=>resolve(r.result);r.onerror=()=>reject(r.error);r.readAsDataURL(data.attachment.blob);});return {id:data.attachment.id,name:data.attachment.name,mime:'application/pdf',size:data.attachment.blob.size,sha256:await digest(data.attachment.blob),base64:url.split(',')[1]};}
export async function encode(data){return {format:'offline-recipe-test',schemaVersion:1,exportedAt:new Date().toISOString(),recipe:data.recipe,attachment:await encodeAttachment(data.attachment)};}
export async function decode(file){if(file.size>15*1024*1024)throw new Error('备份超过测试版 15 MB 上限。');const p=JSON.parse(await file.text());if(p.format!=='offline-recipe-test'||p.schemaVersion!==1)throw new Error('不是此测试版支持的备份格式。');validateRecipe(p.recipe);const a=p.attachment;if(!a||a.id!==p.recipe.instructionsAttachmentId||a.mime!=='application/pdf'||typeof a.name!=='string'||!a.name.length||a.name.length>200||typeof a.base64!=='string'||typeof a.sha256!=='string')throw new Error('附件关联无效。');const bytes=Uint8Array.from(atob(a.base64),c=>c.charCodeAt(0));const blob=new Blob([bytes],{type:'application/pdf'});await checkPdf(blob);if(a.size!==blob.size||a.sha256!==await digest(blob))throw new Error('PDF 附件校验失败。');return {schemaVersion:1,recipe:p.recipe,attachment:{id:a.id,name:a.name,mime:a.mime,blob}};}
export function download(blob,name){const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download=name;document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),60000);}
export async function exportBackup(data,prefix='recipe-backup'){const result=await encode(data);download(new Blob([JSON.stringify(result,null,2)],{type:'application/json'}),`${prefix}-${new Date().toISOString().replace(/[:.]/g,'-')}.json`);}

const MAX_LIBRARY_BACKUP = 50 * 1024 * 1024;
export async function encodeLibrary(library) {
  validateLibrary(library);
  const attachments = [];
  for (const attachment of library.attachments) {
    await checkPdf(attachment.blob);
    attachments.push(await encodeAttachment(attachment));
  }
  const file = new Blob([JSON.stringify({
    format: 'offline-recipe-library', schemaVersion: 1,
    recipes: library.recipes, attachments,
  })], {type: 'application/json'});
  if (file.size > MAX_LIBRARY_BACKUP) throw Error('全库备份超过 50 MB。');
  return file;
}

export async function decodeLibrary(file) {
  if (file.size > MAX_LIBRARY_BACKUP) throw Error('全库备份超过 50 MB。');
  const backup = JSON.parse(await file.text());
  if (backup?.format === 'offline-recipe-test') return migrateLegacyWorkspace(await decode(file));
  if (backup?.format !== 'offline-recipe-library' || backup.schemaVersion !== 1 ||
      !Array.isArray(backup.recipes) || !Array.isArray(backup.attachments)) {
    throw Error('全库备份格式无效。');
  }
  const attachments = [];
  for (const attachment of backup.attachments) {
    if (attachment?.mime !== 'application/pdf' || typeof attachment.base64 !== 'string' ||
        attachment.base64.length > 4 * Math.ceil(MAX_PDF / 3)) throw Error('附件资料无效。');
    const bytes = Uint8Array.from(atob(attachment.base64), character => character.charCodeAt(0));
    const blob = new Blob([bytes], {type: 'application/pdf'});
    await checkPdf(blob);
    if (attachment.size !== blob.size || attachment.sha256 !== await digest(blob)) {
      throw Error('PDF 附件校验失败。');
    }
    attachments.push({id: attachment.id, name: attachment.name, mime: attachment.mime, blob});
  }
  return validateLibrary({schemaVersion: 2, recipes: backup.recipes, attachments});
}
