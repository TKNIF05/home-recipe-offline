const scope = 'https://www.googleapis.com/auth/drive.file';
let preparation;

function loadScript(src) {
  return new Promise((resolve, reject) => {
    const script = document.createElement('script');
    const timer = setTimeout(() => finish(Error('Google 连接超时，请重试。')), 20000);
    function finish(error) {
      clearTimeout(timer);
      script.onload = script.onerror = null;
      if (error) { script.remove(); reject(error); }
      else resolve();
    }
    script.src = src;
    script.onload = () => finish();
    script.onerror = () => finish(Error('Google 连接失败，请检查网络。'));
    document.head.append(script);
  });
}

export function prepareDrive() {
  preparation ??= Promise.all([
    globalThis.google?.accounts ? undefined : loadScript('https://accounts.google.com/gsi/client'),
    globalThis.gapi ? undefined : loadScript('https://apis.google.com/js/api.js'),
  ]).then(() => new Promise((resolve, reject) => {
    gapi.load('picker', {callback: resolve, onerror: () => reject(Error('文件选择器加载失败。')),
      timeout: 20000, ontimeout: () => reject(Error('文件选择器加载超时。'))});
  })).catch(error => { preparation = undefined; throw error; });
  return preparation;
}

// Call directly from a click so the browser can open Google's authorization window.
export function authorizeDrive(config) {
  return new Promise((resolve, reject) => {
    const client = google.accounts.oauth2.initTokenClient({
      client_id: config.clientId, scope, include_granted_scopes: false,
      callback: response => {
        const lifetime = Number(response.expires_in);
        if (response.error || !response.access_token ||
            !Number.isFinite(lifetime) || lifetime <= 60 ||
            !google.accounts.oauth2.hasGrantedAllScopes(response, scope)) {
          reject(Error('尚未获得所选文件的访问授权。'));
        } else resolve({token: response.access_token,
          expiresAt: Date.now() + lifetime * 1000 - 60000});
      },
      error_callback: () => reject(Error('授权窗口已关闭或被浏览器阻止，请重试。')),
    });
    client.requestAccessToken({prompt: 'select_account'});
  });
}

export function chooseDriveFile(config, token) {
  return new Promise(resolve => {
    const picker = new google.picker.PickerBuilder()
      .addView(new google.picker.DocsView().setMimeTypes('application/json,application/octet-stream,text/plain'))
      .setOAuthToken(token).setDeveloperKey(config.apiKey).setAppId(config.projectNumber)
      .setOrigin(location.origin).setCallback(event => {
        if (event.action === google.picker.Action.PICKED) {
          picker.dispose();
          resolve(event.docs[0]?.id ?? null);
        } else if (event.action === google.picker.Action.CANCEL) {
          picker.dispose(); resolve(null);
        }
      }).build();
    picker.setVisible(true);
  });
}
