import {validateLibrary} from './model.js';

function canonical(value) {
  if (Array.isArray(value)) return value.map(canonical);
  if (value && typeof value === 'object') {
    return Object.fromEntries(Object.keys(value).sort().map(key => [key, canonical(value[key])]));
  }
  return value;
}

async function sameAttachment(local, incoming) {
  if (local.name !== incoming.name || local.blob.size !== incoming.blob.size) return false;
  const hashes = await Promise.all([local.blob, incoming.blob].map(async blob =>
    new Uint8Array(await crypto.subtle.digest('SHA-256', await blob.arrayBuffer()))));
  return hashes[0].every((byte, index) => byte === hashes[1][index]);
}

export function recordLocalRevision(library, changedId) {
  const revisions = new Map((library.revisions ?? []).map(revision => [revision.id, revision]));
  for (const id of [...library.recipes.map(recipe => recipe.id), ...(library.deletedRecipeIds ?? [])]) {
    const previous = revisions.get(id);
    if (previous && id !== changedId) continue;
    revisions.set(id, {
      id, token: crypto.randomUUID(),
      ancestors: previous ? [previous.token, ...previous.ancestors].slice(0, 128) : [],
    });
  }
  return {...library, revisions: [...revisions.values()]};
}

function compareHistory(rows, local, incoming) {
  const localHistory = new Map((local.revisions ?? []).map(revision => [revision.id, revision]));
  const incomingHistory = new Map((incoming.revisions ?? []).map(revision => [revision.id, revision]));
  for (const row of rows) {
    if (row.status !== 'conflict') continue;
    const left = localHistory.get(row.id);
    const right = incomingHistory.get(row.id);
    if (!left || !right) continue;
    const incomingIsNewer = right.ancestors.includes(left.token);
    const localIsNewer = left.ancestors.includes(right.token);
    if (incomingIsNewer !== localIsNewer) row.status = incomingIsNewer ? 'update' : 'older';
  }
  return rows;
}

export async function previewMerge(local, incoming) {
  validateLibrary(local);
  validateLibrary(incoming);
  const localRecipes = new Map(local.recipes.map(recipe => [recipe.id, recipe]));
  const localAttachments = new Map(local.attachments.map(attachment => [attachment.id, attachment]));
  const incomingAttachments = new Map(incoming.attachments.map(attachment => [attachment.id, attachment]));
  const rows = [];
  const localDeleted = new Set(local.deletedRecipeIds ?? []);
  for (const recipe of incoming.recipes) {
    const current = localRecipes.get(recipe.id);
    let status = localDeleted.has(recipe.id) ? 'conflict' : 'new';
    if (current) {
      const {instructionsAttachmentId: localPdf, ...localFields} = current;
      const {instructionsAttachmentId: incomingPdf, ...incomingFields} = recipe;
      const sameRecipe = JSON.stringify(canonical(localFields)) === JSON.stringify(canonical(incomingFields));
      const same = sameRecipe && await sameAttachment(
        localAttachments.get(localPdf),
        incomingAttachments.get(incomingPdf),
      );
      status = same ? 'unchanged' : 'conflict';
    }
    rows.push({id: recipe.id, title: recipe.title, localTitle: current?.title ?? (localDeleted.has(recipe.id) ? '已删除' : undefined), status});
  }
  for (const id of incoming.deletedRecipeIds ?? []) {
    const current = localRecipes.get(id);
    if (current) rows.push({id, title: '已删除', localTitle: current.title, status: 'conflict'});
    else if (!localDeleted.has(id)) rows.push({id, title: '删除记录', status: 'deletion'});
  }
  return compareHistory(rows, local, incoming);
}

export async function mergeLibraries(local, incoming, choices) {
  const rows = await previewMerge(local, incoming);
  const recipes = new Map(local.recipes.map(recipe => [recipe.id, recipe]));
  const attachments = new Map(local.attachments.map(attachment => [attachment.id, attachment]));
  const incomingRecipes = new Map(incoming.recipes.map(recipe => [recipe.id, recipe]));
  const incomingAttachments = new Map(incoming.attachments.map(attachment => [attachment.id, attachment]));
  const mappedAttachments = new Map();
  const replacedAttachments = new Set();
  const deleted = new Set(local.deletedRecipeIds ?? []);
  const revisions = new Map((local.revisions ?? []).map(revision => [revision.id, revision]));
  const importedRevisions = new Map((incoming.revisions ?? []).map(revision => [revision.id, revision]));
  for (const row of rows) {
    if (row.status === 'unchanged' || row.status === 'older') continue;
    if (row.status === 'update' && recipes.has(row.id)) {
      replacedAttachments.add(recipes.get(row.id).instructionsAttachmentId);
    }
    if (row.status === 'conflict') {
      const choice = choices.get(row.id);
      if (choice === 'local') continue;
      if (choice !== 'incoming') throw Error('请先选择每条冲突菜谱要保留的版本。');
      const previous = recipes.get(row.id);
      if (previous) replacedAttachments.add(previous.instructionsAttachmentId);
    }
    const revision = importedRevisions.get(row.id);
    if (revision) revisions.set(row.id, revision);
    else revisions.delete(row.id);
    const recipe = incomingRecipes.get(row.id);
    if (!recipe) {
      recipes.delete(row.id);
      deleted.add(row.id);
      continue;
    }
    deleted.delete(row.id);
    const originalId = recipe.instructionsAttachmentId;
    if (!mappedAttachments.has(originalId)) {
      let id = originalId;
      while (attachments.has(id)) id = crypto.randomUUID();
      attachments.set(id, {...incomingAttachments.get(originalId), id});
      mappedAttachments.set(originalId, id);
    }
    recipes.set(row.id, {...recipe, instructionsAttachmentId: mappedAttachments.get(originalId)});
  }
  const used = new Set(Array.from(recipes.values(), recipe => recipe.instructionsAttachmentId));
  for (const id of replacedAttachments) if (!used.has(id)) attachments.delete(id);
  return validateLibrary({...local, recipes: [...recipes.values()], attachments: [...attachments.values()], deletedRecipeIds: [...deleted], revisions: [...revisions.values()]});
}
