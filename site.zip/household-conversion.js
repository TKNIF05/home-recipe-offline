function validRule(rule) {
  return rule && Number.isFinite(rule.from) && rule.from > 0 &&
    Number.isFinite(rule.to) && rule.to > 0 &&
    typeof rule.unit === 'string' && rule.unit.trim().length > 0 && rule.unit.length <= 40;
}

function storageKey(recipeId, line) {
  return 'recipe:household-rule:' + JSON.stringify([recipeId, line.id, line.ingredientId, line.name, line.unitId, line.unit]);
}

export function readHouseholdRule(recipeId, line) {
  try {
    const rule = JSON.parse(localStorage.getItem(storageKey(recipeId, line)));
    if (validRule(rule)) return rule;
  } catch {
    // Browsers can block access to local preferences.
  }
}

export function setupHouseholdConversion(button, form, onRuleChange) {
  const { ingredient, sourceQuantity, targetQuantity, targetUnit, copyConversion } = form.elements;
  const sourceLabel = form.querySelector('[data-source-label]');
  const save = form.querySelector('[data-save-rule]');
  const remove = form.querySelector('[data-remove-rule]');
  const ruleStatus = form.querySelector('[data-rule-status]');
  const copyPanel = form.querySelector('[data-conversion-copy]');
  const applyCopy = form.querySelector('[data-apply-conversion]');
  const copyStatus = form.querySelector('[data-copy-conversion-status]');
  const result = form.querySelector('output');
  const format = new Intl.NumberFormat('zh-CN', { maximumSignificantDigits: 8 });
  let recipeId;
  let lines = [];
  let recipes = [];
  let copies = [];

  function showForm(open) {
    form.hidden = !open;
    button.setAttribute('aria-expanded', String(open));
  }

  function describeRule(rule, sourceUnit) {
    return `${format.format(rule.from)} ${sourceUnit} ≈ ${format.format(rule.to)} ${rule.unit}`;
  }

  function showSavedRule(rule) {
    remove.hidden = !rule;
    ruleStatus.textContent = rule ? '已保存 ' + describeRule(rule, lines[ingredient.selectedIndex].unit) : '';
  }

  function estimate(line, rule) {
    const quantity = line.quantity / rule.from * rule.to;
    if (!Number.isFinite(quantity) || (quantity === 0 && line.quantity > 0)) {
      result.textContent = '结果超出计算范围，请检查输入的用量。';
      return;
    }
    result.textContent = `${line.name} ${format.format(line.quantity)} ${line.unit} ≈ ${format.format(quantity)} ${rule.unit}`;
  }

  function fillRule(rule) {
    sourceQuantity.value = rule?.from ?? '';
    targetQuantity.value = rule?.to ?? '';
    targetUnit.value = rule?.unit ?? '';
  }

  function offerCopies(line) {
    const key = value => value.trim().normalize('NFKC').toLowerCase();
    copies = [];
    if (line) {
      const name = key(line.name);
      const unit = key(line.unit);
      for (const recipe of recipes) {
        if (recipe.id === recipeId) continue;
        for (const item of [...recipe.ingredients, ...recipe.seasonings]) {
          if (key(item.name) !== name || key(item.unit) !== unit) continue;
          const rule = readHouseholdRule(recipe.id, item);
          if (rule) copies.push({ rule, label: recipe.title + ' · ' + describeRule(rule, item.unit) });
        }
      }
    }
    copyConversion.replaceChildren(new Option('选择来源菜谱', ''), ...copies.map((copy, index) =>
      new Option(copy.label, String(index + 1))));
    copyPanel.hidden = !copies.length;
    applyCopy.hidden = true;
    copyStatus.textContent = '';
  }

  function loadRule() {
    const line = lines[ingredient.selectedIndex];
    const rule = line && readHouseholdRule(recipeId, line);
    sourceLabel.textContent = line ? `已知用量（${line.unit}）` : '已知用量';
    fillRule(rule);
    result.textContent = '';
    showSavedRule(rule);
    offerCopies(line);
    if (rule) estimate(line, rule);
  }

  button.addEventListener('click', () => {
    showForm(form.hidden);
    if (!form.hidden) {
      loadRule();
      ingredient.focus();
    }
  });
  ingredient.addEventListener('change', loadRule);
  form.addEventListener('input', event => {
    if (event.target === copyConversion) return;
    result.textContent = '';
    copyStatus.textContent = '';
  });
  copyConversion.onchange = () => {
    applyCopy.hidden = !copyConversion.value;
    copyStatus.textContent = '';
  };
  applyCopy.onclick = () => {
    const copy = copies[Number(copyConversion.value) - 1];
    const line = lines[ingredient.selectedIndex];
    if (!copy || !line) return;
    fillRule(copy.rule);
    estimate(line, copy.rule);
    copyStatus.textContent = '已带入比例，点「保存此比例」后用于营养计算。';
  };
  form.addEventListener('submit', event => {
    event.preventDefault();
    const line = lines[ingredient.selectedIndex];
    const rule = {
      from: sourceQuantity.valueAsNumber,
      to: targetQuantity.valueAsNumber,
      unit: targetUnit.value.trim(),
    };
    if (!line || !validRule(rule)) {
      result.textContent = '请填入两个大于 0 的用量和目标单位。';
      return;
    }

    estimate(line, rule);
    if (event.submitter !== save) return;
    try {
      localStorage.setItem(storageKey(recipeId, line), JSON.stringify(rule));
      showSavedRule(rule);
      copyStatus.textContent = '';
    } catch {
      ruleStatus.textContent = '本机无法保存这个比例。';
      return;
    }
    onRuleChange();
  });

  remove.addEventListener('click', () => {
    const line = lines[ingredient.selectedIndex];
    if (!line) return;
    try {
      localStorage.removeItem(storageKey(recipeId, line));
    } catch {
      ruleStatus.textContent = '本机无法删除这个比例。';
      return;
    }
    loadRule();
    ruleStatus.textContent = '已删除保存的比例。';
    sourceQuantity.focus();
    onRuleChange();
  });

  return {
    render(recipe, savedRecipes) {
      recipeId = recipe?.id;
      recipes = savedRecipes;
      lines = recipe ? [...recipe.ingredients, ...recipe.seasonings] : [];
      ingredient.replaceChildren(...lines.map(line => new Option(`${line.name} · ${format.format(line.quantity)} ${line.unit}`)));
      showForm(false);
      button.hidden = !lines.length;
    },
    openFor(index) {
      if (!lines[index]) return;
      if (form.hidden || ingredient.selectedIndex !== index) {
        ingredient.selectedIndex = index;
        loadRule();
      }
      if (!targetUnit.value) targetUnit.value = '克';
      showForm(true);
      sourceQuantity.focus();
    },
  };
}
