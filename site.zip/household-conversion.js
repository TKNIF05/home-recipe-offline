function validRule(rule) {
  return rule && Number.isFinite(rule.from) && rule.from > 0 &&
    Number.isFinite(rule.to) && rule.to > 0 &&
    typeof rule.unit === 'string' && rule.unit.trim().length > 0 && rule.unit.length <= 40;
}

export function setupHouseholdConversion(button, form) {
  const { ingredient, sourceQuantity, targetQuantity, targetUnit } = form.elements;
  const sourceUnit = form.querySelector('[data-source-unit]');
  const save = form.querySelector('[data-save-rule]');
  const remove = form.querySelector('[data-remove-rule]');
  const ruleStatus = form.querySelector('[data-rule-status]');
  const result = form.querySelector('output');
  const format = new Intl.NumberFormat('zh-CN', { maximumSignificantDigits: 8 });
  let recipeId;
  let lines = [];

  function showForm(open) {
    form.hidden = !open;
    button.setAttribute('aria-expanded', String(open));
  }

  function storageKey(line) {
    return 'recipe:household-rule:' + JSON.stringify([recipeId, line.id, line.ingredientId, line.name, line.unitId, line.unit]);
  }

  function showSavedRule(rule) {
    remove.hidden = !rule;
    ruleStatus.textContent = rule
      ? `已保存 ${format.format(rule.from)} ${sourceUnit.textContent} ≈ ${format.format(rule.to)} ${rule.unit}`
      : '';
  }

  function estimate(line, rule) {
    const quantity = line.quantity / rule.from * rule.to;
    if (!Number.isFinite(quantity) || (quantity === 0 && line.quantity > 0)) {
      result.textContent = '结果超出计算范围，请检查输入的用量。';
      return;
    }
    result.textContent = `${line.name} ${format.format(line.quantity)} ${line.unit} ≈ ${format.format(quantity)} ${rule.unit}`;
  }

  function loadRule() {
    const line = lines[ingredient.selectedIndex];
    let rule;
    if (line) {
      try {
        const stored = JSON.parse(localStorage.getItem(storageKey(line)));
        if (validRule(stored)) rule = stored;
      } catch {
        // Trial calculations are available even when browser storage cannot be read.
      }
    }
    sourceUnit.textContent = line?.unit ?? '';
    sourceQuantity.value = rule?.from ?? '';
    targetQuantity.value = rule?.to ?? '';
    targetUnit.value = rule?.unit ?? '';
    result.textContent = '';
    showSavedRule(rule);
    if (rule) estimate(line, rule);
  }

  button.addEventListener('click', () => {
    showForm(form.hidden);
    if (!form.hidden) {
      loadRule();
      ingredient.focus();
    }
  });
  ingredient.addEventListener('change', loadRule);
  form.addEventListener('input', () => { result.textContent = ''; });
  form.addEventListener('submit', event => {
    event.preventDefault();
    const line = lines[ingredient.selectedIndex];
    const rule = {
      from: sourceQuantity.valueAsNumber,
      to: targetQuantity.valueAsNumber,
      unit: targetUnit.value.trim(),
    };
    if (!line || !validRule(rule)) {
      result.textContent = '请填入两个大于 0 的用量和目标单位。';
      return;
    }

    estimate(line, rule);
    if (event.submitter !== save) return;
    try {
      localStorage.setItem(storageKey(line), JSON.stringify(rule));
      showSavedRule(rule);
    } catch {
      ruleStatus.textContent = '本机无法保存这个比例。';
    }
  });

  remove.addEventListener('click', () => {
    const line = lines[ingredient.selectedIndex];
    if (!line) return;
    try {
      localStorage.removeItem(storageKey(line));
    } catch {
      ruleStatus.textContent = '本机无法删除这个比例。';
      return;
    }
    loadRule();
    ruleStatus.textContent = '已删除保存的比例。';
    sourceQuantity.focus();
  });

  return recipe => {
    recipeId = recipe?.id;
    lines = recipe ? [...recipe.ingredients, ...recipe.seasonings] : [];
    ingredient.replaceChildren(...lines.map(line => new Option(`${line.name} · ${format.format(line.quantity)} ${line.unit}`)));
    showForm(false);
    button.hidden = !lines.length;
  };
}
