export const RECIPE_ID='recipe-test-potato-chicken-001';
export function validateLibrary(value){
 if(value?.schemaVersion!==2||!Array.isArray(value.recipes)||!Array.isArray(value.attachments))throw Error('菜谱库格式无效。');
 const ids=new Set(),attachments=new Map();
 for(const a of value.attachments){if(!a||typeof a.id!=='string'||!a.id.length||a.id.length>120||attachments.has(a.id)||typeof a.name!=='string'||!a.name.length||a.name.length>200||a.mime!=='application/pdf'||!(a.blob instanceof Blob)||!a.blob.size||a.blob.size>10*1024*1024)throw Error('附件资料无效。');attachments.set(a.id,a);}
 for(const r of value.recipes){validateRecipe(r);if(ids.has(r.id)||!attachments.has(r.instructionsAttachmentId))throw Error('菜谱 ID 重复或附件关联无效。');ids.add(r.id);}
 return value;
}
export function migrateLegacyWorkspace(value){
 if(value?.schemaVersion!==1)throw Error('不支持的旧数据格式。');
 return validateLibrary({schemaVersion:2,recipes:[structuredClone(value.recipe)],attachments:[structuredClone(value.attachment)]});
}
export function singleWorkspace(library,recipeId){
 validateLibrary(library);
 const recipe=recipeId?library.recipes.find(r=>r.id===recipeId):(library.recipes.length===1?library.recipes[0]:null);
 if(!recipe)throw Error('未找到指定菜谱，或当前界面不支持此菜谱库。');
 return {schemaVersion:1,recipe,attachment:library.attachments.find(a=>a.id===recipe.instructionsAttachmentId)};
}
export function sample(pdf){const now=new Date().toISOString();return {schemaVersion:1,recipe:{id:RECIPE_ID,title:'土豆烧鸡腿',servings:2,createdAt:now,updatedAt:now,notes:'测试菜谱：按家里的习惯记录用量。PDF 是独立示例，内容无需与这里的材料对应。',instructionsAttachmentId:'pdf-test-001',ingredients:[{id:'line-1',ingredientId:'chicken-thigh',name:'鸡腿',quantity:2,unitId:'piece',unit:'个'},{id:'line-2',ingredientId:'potato',name:'土豆',quantity:2,unitId:'piece',unit:'个'},{id:'line-3',ingredientId:'ginger',name:'生姜',quantity:3,unitId:'slice',unit:'片'}],seasonings:[{id:'line-4',ingredientId:'light-soy',name:'生抽',quantity:1,unitId:'home-large-spoon',unit:'家庭大勺'},{id:'line-5',ingredientId:'oil',name:'食用油',quantity:1,unitId:'home-large-spoon',unit:'家庭大勺'},{id:'line-6',ingredientId:'salt',name:'盐',quantity:0.5,unitId:'home-small-spoon',unit:'家庭小勺'}]},attachment:{id:'pdf-test-001',name:'sample-process.pdf',mime:'application/pdf',blob:pdf}};}
export function validateRecipe(r){
 const str=(s,n)=>typeof s==='string'&&s.length>0&&s.length<=n;
 if(!r||!str(r.id,120)||!str(r.title,80)||!Number.isFinite(r.servings)||r.servings<.1||r.servings>100||typeof r.notes!=='string'||r.notes.length>1000||!str(r.instructionsAttachmentId,120)||!['createdAt','updatedAt'].every(k=>typeof r[k]==='string'&&Number.isFinite(Date.parse(r[k]))))throw new Error('菜谱资料无效。');
 for(const k of ['ingredients','seasonings']){if(!Array.isArray(r[k])||r[k].length>100)throw new Error('材料列表无效。');for(const x of r[k])if(!x||!str(x.id,120)||!str(x.ingredientId,120)||!str(x.name,80)||!str(x.unitId,120)||!str(x.unit,40)||!Number.isFinite(x.quantity)||x.quantity<0)throw new Error('材料用量无效。');}
}
