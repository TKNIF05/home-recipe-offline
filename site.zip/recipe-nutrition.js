import { nutritionFoods } from './nutrition-foods.js';
import { readHouseholdRule } from './household-conversion.js';

const nutrients = [
  ['kcal', '热量', '千卡'], ['protein', '蛋白质', '克'], ['fat', '脂肪', '克'],
  ['carbs', '碳水', '克'], ['sodium', '钠', '毫克'], ['sugar', '糖', '克'],
];
const foods = new Map(nutritionFoods.map(food => [food.id, food]));
const massUnits = new Map([['克', 1], ['g', 1], ['千克', 1000], ['公斤', 1000], ['kg', 1000], ['毫克', .001], ['mg', .001]]);
const massFactor = unit => massUnits.get(unit.trim().normalize('NFKC').toLowerCase());

export function validNutrition(value) {
  if (!value || typeof value !== 'object' || Array.isArray(value) || Object.keys(value).length !== 1) return false;
  if (Object.hasOwn(value, 'foodId')) return typeof value.foodId === 'string' && /^\d{1,15}$/.test(value.foodId);
  const manual = value.values;
  if (!manual || typeof manual !== 'object' || Array.isArray(manual)) return false;
  const fields = Object.entries(manual);
  return fields.length > 0 && fields.every(([key, amount]) =>
    nutrients.some(([id]) => id === key) && Number.isFinite(amount) && amount >= 0 && amount <= 1000000);
}

function edibleGrams(recipeId, line) {
  const factor = massFactor(line.unit);
  if (factor !== undefined) return line.quantity * factor;
  const rule = readHouseholdRule(recipeId, line);
  const target = rule && massFactor(rule.unit);
  return target === undefined ? NaN : line.quantity / rule.from * rule.to * target;
}

export function renderNutritionSummary(container, portions, perServing = false, openEditor, showMissing = true) {
  container.replaceChildren();
  if (!portions.length) return;
  const metrics = perServing ? nutrients.slice(0, 1) : nutrients;
  const totals = metrics.map(() => ({ value: 0, count: 0 }));
  const missing = new Map();
  let count = 0;
  for (const { recipe, servings } of portions) {
    const lines = recipe ? ['ingredients', 'seasonings'].flatMap(kind =>
      recipe[kind].filter(line => line.quantity > 0).map(line => ({kind, line}))) : [];
    if (!lines.length) {
      count += 1;
      const label = recipe ? recipe.title + '（无可计算用量）' : '已删除的菜谱';
      missing.set(label, {label});
    }
    for (const {kind, line} of lines) {
      count += 1;
      const label = perServing ? line.name : recipe.title + ' / ' + line.name;
      const report = (reason, target = 'source') => {
        const text = label + '（' + reason + '）';
        missing.set(JSON.stringify([recipe.id, kind, line.id, reason]), {label: text, recipe, kind, line, target});
      };
      const values = foods.get(line.nutrition?.foodId)?.values ?? line.nutrition?.values;
      const grams = edibleGrams(recipe.id, line);
      if (!Number.isFinite(grams) || grams <= 0) {
        report('缺可食克数', 'weight');
        continue;
      }
      if (!values) {
        report('缺营养来源');
        continue;
      }
      const absent = [];
      const overflow = [];
      for (const [index, [key, nutrient]] of metrics.entries()) {
        if (!Object.hasOwn(values, key)) {
          absent.push({key, nutrient});
          continue;
        }
        const amount = grams / 100 * (servings / recipe.servings) * values[key];
        const total = totals[index];
        if (!Number.isFinite(amount) || !Number.isFinite(total.value + amount)) {
          overflow.push(nutrient);
          continue;
        }
        total.value += amount;
        total.count += 1;
      }
      if (absent.length) report('缺' + absent.map(item => item.nutrient).join('、'), absent[0].key);
      if (overflow.length) report(overflow.join('、') + '超出计算范围');
    }
  }
  const heading = document.createElement('h3');
  heading.textContent = perServing ? '每份热量估算' : '当天营养估算';
  const list = document.createElement('ul');
  const format = new Intl.NumberFormat('zh-CN', { maximumFractionDigits: 1 });
  for (const [index, [, label, unit]] of metrics.entries()) {
    const item = document.createElement('li');
    const total = totals[index];
    item.textContent = label + ' ' + (total.count ? format.format(total.value) + ' ' + unit +
      (total.count < count ? '（部分）' : '') : '暂无数据');
    list.append(item);
  }
  container.append(heading, list);
  if (showMissing && missing.size) {
    const note = document.createElement('p');
    note.className = 'hint';
    note.textContent = '估算不完整';
    const details = document.createElement('ul');
    details.className = 'nutrition-missing';
    for (const {label, recipe, kind, line, target} of missing.values()) {
      const item = document.createElement('li');
      if (openEditor && line) {
        const button = document.createElement('button');
        button.type = 'button';
        button.className = 'textbutton';
        button.textContent = label;
        button.title = label;
        button.onclick = () => openEditor(recipe, kind, line, target);
        item.append(button);
      } else {
        item.textContent = label;
      }
      details.append(item);
    }
    container.append(note, details);
  }
}

function nutritionMatches(recipes, recipeId, name) {
  const match = name.trim().normalize('NFKC').toLowerCase();
  if (!match) return [];
  const matches = [];
  for (const recipe of recipes) {
    if (recipe.id === recipeId) continue;
    for (const item of [...recipe.ingredients, ...recipe.seasonings]) {
      if (item.name.trim().normalize('NFKC').toLowerCase() !== match || !validNutrition(item.nutrition)) continue;
      const food = foods.get(item.nutrition.foodId);
      if (!food && !item.nutrition.values) continue;
      const source = food?.label ?? '手填资料';
      matches.push({
        label: recipe.title + ' · ' + item.quantity + ' ' + item.unit + ' · ' + source,
        nutrition: item.nutrition,
      });
    }
  }
  return matches;
}

export function appendNutritionEditor(row, recipeId, line, recipes) {
  const existing = line.nutrition;
  const name = row.querySelector('[data-field="name"]');
  const quantity = row.querySelector('[data-field="quantity"]');
  const unit = row.querySelector('[data-field="unit"]');
  const toggle = document.createElement('button');
  toggle.type = 'button';
  toggle.dataset.editNutrition = '';
  toggle.textContent = existing ? '编辑营养资料' : '填写营养资料';
  toggle.setAttribute('aria-expanded', 'false');
  const panel = document.createElement('div');
  panel.className = 'nutrition-editor';
  panel.hidden = true;
  toggle.onclick = () => {
    panel.hidden = !panel.hidden;
    toggle.setAttribute('aria-expanded', String(!panel.hidden));
    if (!panel.hidden) {
      updateWeight();
      updateMatches();
    }
  };

  const source = document.createElement('select');
  source.append(new Option('未填写', ''), ...nutritionFoods.map(food => new Option(food.label, food.id)),
    new Option('手动填写每 100 克', 'manual'));
  if (existing?.foodId && !foods.has(existing.foodId)) {
    source.append(new Option('此版本暂无条目 ' + existing.foodId, existing.foodId));
  }
  source.value = existing?.foodId ?? (existing?.values ? 'manual' : '');
  const sourceLabel = document.createElement('label');
  sourceLabel.append('营养来源', source);
  const weight = document.createElement('p');
  weight.className = 'hint';
  const reference = document.createElement('p');
  reference.className = 'hint';
  const format = new Intl.NumberFormat('zh-CN', { maximumFractionDigits: 2 });
  function updateWeight() {
    const amount = quantity.valueAsNumber;
    if (!Number.isFinite(amount) || !unit.value.trim()) {
      weight.textContent = '请先填写菜谱用量和单位。';
      return;
    }
    const grams = edibleGrams(recipeId, { ...line, name: name.value.trim(), unit: unit.value.trim(), quantity: amount });
    weight.textContent = Number.isFinite(grams) && grams >= 0
      ? '整道菜用量约 ' + format.format(grams) + ' 克，按可食重量计算。'
      : '暂时无法换算为克。可用质量单位，或为这项食材保存换算成克的比例。';
  }
  const manual = document.createElement('div');
  manual.className = 'nutrition-fields';
  const basis = document.createElement('input');
  basis.type = 'number';
  basis.inputMode = 'decimal';
  basis.step = 'any';
  basis.min = '0';
  basis.value = '100';
  const basisLabel = document.createElement('label');
  basisLabel.append('以下营养值对应的重量（克）', basis);
  const hint = document.createElement('p');
  hint.className = 'hint';
  hint.textContent = '按标签填写对应重量和数值。未知可留空，保存后统一显示每 100 克的值。';
  const fields = nutrients.map(([key, label, unit]) => {
    const input = document.createElement('input');
    input.dataset.nutrient = key;
    input.type = 'number';
    input.inputMode = 'decimal';
    input.step = 'any';
    input.min = '0';
    input.max = '1000000';
    input.value = existing?.values?.[key] ?? '';
    const field = document.createElement('label');
    field.append(label + '（' + unit + '）', input);
    manual.append(field);
    return [key, input];
  });
  const copyPanel = document.createElement('div');
  copyPanel.className = 'copy-controls';
  copyPanel.hidden = true;
  const copySource = document.createElement('select');
  copySource.dataset.copySource = '';
  const copyLabel = document.createElement('label');
  copyLabel.append('其他菜谱里的同名食材', copySource);
  const copyButton = document.createElement('button');
  copyButton.type = 'button';
  copyButton.className = 'button secondary';
  copyButton.textContent = '采用这份资料';
  copyButton.hidden = true;
  const copyStatus = document.createElement('p');
  copyStatus.className = 'hint';
  copyStatus.setAttribute('role', 'status');
  let matches = [];
  function updateMatches() {
    matches = nutritionMatches(recipes, recipeId, name.value);
    copyPanel.hidden = !matches.length;
    copySource.replaceChildren(new Option('选择来源菜谱', ''), ...matches.map((match, index) =>
      new Option(match.label, String(index + 1))));
    copyButton.hidden = true;
    copyStatus.textContent = '';
  }
  copySource.onchange = () => {
    copyButton.hidden = !copySource.value;
    copyStatus.textContent = '';
  };
  copyButton.onclick = () => {
    const match = matches[Number(copySource.value) - 1];
    if (!match) return;
    source.value = match.nutrition.foodId ?? 'manual';
    basis.value = '100';
    for (const [key, input] of fields) input.value = match.nutrition.values?.[key] ?? '';
    updateFields();
    copyStatus.textContent = '已带入资料，保存菜谱后生效。';
  };
  copyPanel.append(copyLabel, copyButton, copyStatus);

  function updateFields() {
    manual.hidden = source.value !== 'manual';
    hint.hidden = manual.hidden;
    basisLabel.hidden = basis.disabled = manual.hidden;
    for (const [, input] of fields) input.disabled = manual.hidden;
    const food = foods.get(source.value);
    reference.textContent = food
      ? '每 100 克 · ' + nutrients.map(([key, label, unit]) =>
        label + ' ' + format.format(food.values[key]) + ' ' + unit).join(' · ') + ' · USDA FDC ' + food.id
      : '';
    reference.hidden = !food;
  }
  updateFields();
  source.onchange = updateFields;
  name.addEventListener('input', () => {
    source.value = '';
    basis.value = '100';
    for (const [, input] of fields) input.value = '';
    updateFields();
    updateWeight();
    if (!panel.hidden) updateMatches();
  });
  quantity.addEventListener('input', updateWeight);
  unit.addEventListener('input', updateWeight);
  panel.append(weight, sourceLabel, reference, basisLabel, hint, manual, copyPanel);
  row.append(toggle, panel);

  return () => {
    if (!source.value) return;
    if (source.value !== 'manual') return { foodId: source.value };
    const entered = fields.filter(([, input]) => input.value !== '');
    if (!entered.length) return;
    const grams = basis.valueAsNumber;
    if (!Number.isFinite(grams) || grams <= 0) {
      basis.focus();
      throw Error('营养值对应的重量必须大于 0 克。');
    }
    const values = Object.fromEntries(entered.map(([key, input]) => [
      key, grams === 100 ? input.valueAsNumber : input.valueAsNumber * 100 / grams,
    ]));
    if (!validNutrition({values})) throw Error('换算后的营养值超出范围，请检查标签重量和数值。');
    return {values};
  };
}
